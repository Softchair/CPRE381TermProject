This folder contains all the top level design files and diagrams for use
This includes the control signals chart and other relevant information
