This folder contains all the files related to the fetch logic for the PC (program counter)
